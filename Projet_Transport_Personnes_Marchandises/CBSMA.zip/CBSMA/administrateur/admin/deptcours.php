<html>
<head><title>anass</title>
<link rel="stylesheet" type="text/css" href="soufiane2.css">
<script src="jquery-1.11.2.min.js"></script>
</head>
<body>
<?php
session_start();

$_SESSION['nom']=$_POST['nom'];
$_SESSION['prenom']=$_POST['prenom'];
$_SESSION['login']=$_POST['login'];
$_SESSION['mdp']=$_POST['mdp'];

echo '<form id="f"method="post" action="insererprofesseur.php?sss">
  <div id="1">
  <h1>Cours</h1>
  <div class="question">
    <input type="text" name="cours" id="c" required/>
    <label>Si plusieurs cours separer entre eux avec ,</label>
  </div>
  <div class="a question" ></div></div>
  <div id="2">
      <h1>Departement</h1>

  <div class="question">
    <input type="text" name="nbdept" id="d" required/>
    <label> Si plusieurs Departement separer entre eux avec ,</label>
  </div>
  <div class="question b" ></div>
  </div>

  
  <button>Submit</button>
</form>';
?>
</body>
</html>