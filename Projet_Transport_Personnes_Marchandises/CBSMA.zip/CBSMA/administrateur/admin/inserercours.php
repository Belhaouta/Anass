<?php

 include("connecter.php");
  $bdd=connecter();
  $req0 = $bdd->prepare('SELECT count(*) FROM  Cours where LibelleCours="'.$_POST['Cours'].'" ');
  $req0->execute();
  $resultat = $req0->fetch();
  if($resultat[0]==1){echo 'impossible';}
  else{  
  $req0 = $bdd->prepare('insert into Cours values("","'.$_POST['Cours'].'") ');
  $req0->execute();
  
  
  }
  


?>