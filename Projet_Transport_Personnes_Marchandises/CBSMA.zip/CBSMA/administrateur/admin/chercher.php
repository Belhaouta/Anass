<?php
if(isset($_GET['id'])){

  include("connecter.php");
  $bdd=connecter();
  $json = array();
  $dep= explode(" ",$_GET['id']);
  if(!isset($dep[1])){$dep[1]=' ';}
  $req0 = $bdd->prepare('select concat(nom,"-",prenom) as f,NumeroProfesseur from professeur where prenom like "'.$dep[1].'%" or nom like "'.$dep[0]. '%"  '); 
  $req0->execute(); 
   
   
    while( $data=$req0->fetch()) {
        $json[$data[1]][] = utf8_encode($data['f']);
    }
   
   
   
   
     
    // envoi du résultat au success
    echo json_encode($json);

	}
?>
 