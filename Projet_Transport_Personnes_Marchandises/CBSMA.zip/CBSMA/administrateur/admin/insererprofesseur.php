<?php
session_start();
 include("connecter.php");
  $bdd=connecter();
  $req0 = $bdd->prepare('SELECT count(*) FROM Professeur where identifiant="'.$_SESSION['login'].'" ');
  $req0->execute();
  $resultat = $req0->fetch();
  if($resultat[0]==1){echo 'impossible';}
  else{  
  $req0 = $bdd->prepare('insert into professeur values(null,"'.$_SESSION['nom'].'",
  "'.$_SESSION['prenom'].'","'.$_SESSION['login'].'","'.$_SESSION['mdp'].'"," ") ');
  $req0->execute();
  
    $req0 = $bdd->prepare('SELECT * FROM `professeur` order by NumeroProfesseur desc ');
    $req0->execute();
    $data=$req0->fetch();
  $dep= explode(",",$_POST['nbdept']);
  $salle= explode(",",$_POST['cours']);
  for($i=0;$i<sizeof($dep);$i++){
  
      $req0 = $bdd->prepare('SELECT * FROM Departement where LibelleDpt="'.$dep[$i].'" ');
       $req0->execute();
       $d=$req0->fetch();  
       $req0 = $bdd->prepare('insert into profdpt values("'.$data[0].'","'.$d[0].'")');
       $req0->execute();
						   
						   }
						   
	for($i=0;$i<sizeof($salle);$i++){
	
	   $req0 = $bdd->prepare('SELECT * from cours where LibelleCours="'.$salle[$i].'" ');
       $req0->execute();
       $s=$req0->fetch();
       $req0 = $bdd->prepare('insert into CoursSalle values("'.$data[0].'","'.$s[0].'")');
       $req0->execute();
						   
						   }

  
  }
  


?>