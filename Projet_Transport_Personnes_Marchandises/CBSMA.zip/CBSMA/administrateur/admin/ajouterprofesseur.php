<html>
<body>
<head><title>anass</title></head>
 <link rel="stylesheet" type="text/css" href="soufiane2.css">
<form method="post" action="  deptcours.php">
  <h1>Ajouter un professeur</h1>
  <div class="question">
    <input type="text" name="nom" required/>
    <label>Nom</label>
  </div>
  <div class="question">
    <input type="text" name="prenom" required/>
    <label>Prenom</label>
  </div>
  <div class="question">
    <input type="text"name="login" required/>
    <label>Login</label>
  </div>
  <div class="question">
    <input type="text" name="mdp"required/>
    <label>Mot de passe</label>
  </div>
  <div class="question">
    <input type="text" required/>
    <label>Retapez le mot de passe</label>
  </div>

  <div class="question">
    <select>
   <option>ss</option>
   </select>
   
  </div>
  <button>OK</button>

 
</form>
</body>
</html>