<html><head>
<!--<meta http-equiv="content-type" content="text/html; charset=UTF-8">-->
	<title>SAFARCOM - Transport de personnes </title>
	<link rel="stylesheet" type="text/css" href="style.css"> 
	<link rel="shortcut icon" href="http://safarcom.fr/logo.ico">

	</head>
	
	
<body>

<a href="#"> <img class="CBSMA_img" src="Safarcom.png"> </a>

<div id="menu">

	<ul>
	
	   <li class="active"><a href="Accueil.php"><span>Accueil</span></a></li>
	   <li> <a href="Apropos.php"><span>� propos de nous</span></a></li>
	    <li class="liste1"><?php $type="TP"; echo '<a href="connexion.php?type='.$type.'"><span>Transport de personnes</span></a>';?>	   
	   </li>
	   <li class="liste1"><?php $type="TM"; echo '<a href="connexion.php?type='.$type.'"><span>Transport de marchandises</span></a>';?>
	   </li>
	   <li> <a href="comission.php"><span>Commission de transport</span></a></li>
	   
	   <li class="last"> <a href="contact.php"><span>Contact</span></a></li>
	   
	</ul>
	
</div>
<div class="photo">
<h1>Commision de tronsport</h1>

</div>

<div class="content">
	<h2>Id�e global</h2>
	<p>
	
	 Le commissionnaire est d�fini comme � tout prestataire de services qui organise librement et fait ex�cuter, sous sa responsabilit�, et en son nom propre, le d�placement des marchandises d�un lieu � un autre selon les modes et moyens de son choix pour le compte d�un donneur d�ordre � (article 2-2).

Pour sa part, le donneur d�ordre est d�fini comme � la partie (le commettant) qui contracte avec le commissionnaire de transport � (article 2-3). 
	</p>
	</div>
<div class="partie">
<h5 > CONTACTEZ-NOUS:</h5>
<div class="sous-titre">
Tel: 0661785959
<br>
Email: Safarcom.fr
</div>

<h5 > SAFARCOM TRANSPORTS DE PERSONNES </h5>
<div class="sous-titre">
Copyright � 2017 - TOUS DROITS R�SERV�S / Webmaster:#
</div>
<!--
<li> Conditions g&eacute;n&eacute;rales</li>
<li> Mentions l&eacute;gales </li>
<li> Politique de confidentialit&eacute; </li>
-->


</div>


</body></html>