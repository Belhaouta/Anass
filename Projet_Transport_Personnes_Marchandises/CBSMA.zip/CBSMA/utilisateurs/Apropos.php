<html><head>
<!--<meta http-equiv="content-type" content="text/html; charset=UTF-8">-->
	<title>SAFARCOM - Transport de personnes </title>
	<link rel="stylesheet" type="text/css" href="style.css"> 
	<link rel="shortcut icon" href="http://safarcom.fr/logo.ico">

	</head>
	
	
<body>

<a href="#"> <img class="CBSMA_img" src="Safarcom.png"> </a>

<div id="menu">

	<ul>
	
	   <li class="active"><a href="Accueil.php"><span>Accueil</span></a></li>
	   <li> <a href="Apropos.php"><span>� propos de nous</span></a></li>
	   <li class="liste1"><?php $type="TP"; echo '<a href="connexion.php?type='.$type.'"><span>Transport de personnes</span></a>';?>	   
	   </li>
	   <li class="liste1"><?php $type="TM"; echo '<a href="connexion.php?type='.$type.'"><span>Transport de marchandises</span></a>';?>
	   </li>
	   <li> <a href="comission.php"><span>Commission de transport</span></a></li>
	   
	   <li class="last"> <a href="contact.php"><span>Contact</span></a></li>
	   
	</ul>
	
</div>

<div class="photo">
<h1>A propos de nous</h1>

</div>


<div class="princip">
<img id="p1" src="luxe.jpg"/>
</div>
<div class="princip">
<div class="div1">
<p>
SafarCom (avec CBSMA), est une entreprise reprise en 2015, disposant d'une multitude d'activit�s permettant d'offrir de nombreux 
services au client, autant dans le transport que dans la domiciliation. Son personnel se charge de transporter des bagages/marchandises 
vers le Maghreb (Maroc, Alg�rie...), mais aussi du transport de personnes telles que les navettes qui conduisent vers les a�roports, etc. 
Il y a �galement les VTC, qui constituent notamment une facette importante de son activit�. 
</p>

</div>
</div>

<div class="princip1">
<div class="div2">
<p>
L'entreprise agit aussi dans un autre domaine, tel que le conseil, avec la domiciliation, et l'aide � la gestion d'entreprise sur le point 
administratif ou commercial. Elle met � disposition des bureaux afin de r�ceptionner des clients pour des meetings, 
permet aussi de faciliter les d�marches concernant la cr�ation d'entreprise, le transfert de si�ge, ainsi que les d�marches administratives.  
</p>

</div>
</div>

<div class="princip1">
<img id="p2" src="car2.jpg"/>
</div>

<div class="partie">
<h5 > CONTACTEZ-NOUS:</h5>
<div class="sous-titre">
Tel: 0661785959
<br>
Email: Safarcom.fr
</div>

<h5 > SAFARCOM TRANSPORTS DE PERSONNES </h5>
<div class="sous-titre">
Copyright � 2017 - TOUS DROITS R�SERV�S / Webmaster:#
</div>
<!--
<li> Conditions g&eacute;n&eacute;rales</li>
<li> Mentions l&eacute;gales </li>
<li> Politique de confidentialit&eacute; </li>
-->


</div>


</body></html>